
   ___    _  __    ___             _  _                     _     
  |   \  | |/ /   / __|     o O O | || |   __ _     __     | |__  
  | |) | | ' <   | (__     o      | __ |  / _` |   / _|    | / /  
  |___/  |_|\_\   \___|   TS__[O] |_||_|  \__,_|   \__|_   |_\_\  
_|"""""|_|"""""|_|"""""| {======|_|"""""|_|"""""|_|"""""|_|"""""| 
"`-0-0-'"`-0-0-'"`-0-0-'./o--000'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-' 
  _____                    _ __     _              _              
 |_   _|   ___    _ __    | '_ \   | |    __ _    | |_     ___    
   | |    / -_)  | '  \   | .__/   | |   / _` |   |  _|   / -_)   
  _|_|_   \___|  |_|_|_|  |_|__   _|_|_  \__,_|   _\__|   \___|   
_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|  
"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'  

A 1.0 U version of this game is required. Header doesn't matter for loading and this produces a new ROM with no header.

This is a hacking template you can apply to any DKC 1.0 U ROM. If you already have a hack, don't worry. You can apply this and your hack 'should' be safe. I use a few spots of free space. 

I use:
0xa6c50-0xa67fff
0x12fe8c-0x12ffff
0x23e1a9-0x23ffff
0x35ff00-35ffff

as well as various patches throughout the game. A few things are changed primarily. 
1. Text has been added to the overworld HUD. This is useful for putting version numbers or something else creative. You can also elect to leave the textbox empty to have no HUD appear. 
2. Quick deaths are now a thing. Dying will instantly start you over, instead of playing that slow death animation. Start select to exit the current level has been enabled all the time (minus bosses).
3. You are given the option to skip K Rool's fake credits.

Shoutouts to Otto, SilentWolf, for inspiring me to make this!

SPECIAL THANKS
Myself086